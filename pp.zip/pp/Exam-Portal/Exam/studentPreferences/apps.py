from django.apps import AppConfig


class StudentpreferencesConfig(AppConfig):
    name = 'studentPreferences'
